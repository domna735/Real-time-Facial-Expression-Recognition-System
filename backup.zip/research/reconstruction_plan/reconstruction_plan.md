0. Freeze dataset index + integrity gates (do this first)
    - Goal: make training reproducible and prevent silent data drops.
    - Produce a single CSV index (v1) with at least: `image_path`, `label`, `source`, `split`.
       - If following the interim report exactly, also include: `quality_score` and a recorded dataset `sha256`/hash manifest.
    - Mandatory checks (fail-fast):
       - paths exist; image decodes; label ∈ {Angry, Disgust, Fear, Happy, Sad, Surprise, Neutral}
       - optional but recommended: per-file SHA256 manifest to detect corruption
       - optional alignment gate (`--require-aligned`) if using aligned-only training
    - Split policy (recommended):
       - keep official dataset splits when available (e.g., RAFDB train/test; FERPlus train/val/test)
       - for sources without `val`, carve a deterministic per-source stratified fraction from `train` (seeded)

1. Rebuild minimum teacher models
    - Models: ResNet18, ResNet50, EfficientNet-B3, ViT, ConvNeXt-Tiny
    - Purpose: generate strong/calibrated teachers for KD/DKD
    - Match interim report teacher protocol where possible:
       - ArcFace head (m=0.35, s=30), warmup + margin schedule, balanced sampling, effective-number weighting
       - Optimizer: AdamW (lr=3e-4, wd=0.05), cosine schedule w/ warmup, ~60 epochs
       - Augmentation: random crop/flip/color jitter + CLAHE (and whatever you used originally)
    - Required artifacts: alignmentreport.json, calibration.json, reliabilitymetrics.json

2. Rebuild ensumable teacher models
   - Pairwise (e.g., RN18+B3) and four-way split combinations
   - For multi-teacher KD/DKD training
   - Required artifacts: ensembleconfig.json, ensemblealignment_gate.json

3. Rebuild student model (core group only)
   - Backbone: MobileNetV3-Large (timm mobilenetv3large100)
   - KD/DKD training with seeds (1337, 2025, 42)
   - Match interim report student protocol where possible:
     - KD: α≈0.5, T=2.0 with T^2 scaling
     - DKD: α≈0.5, β≈4.0, T=2.0 with T^2 scaling
     - Evaluate macro-F1, per-class F1, minority-F1, ECE/NLL/Brier
   - Required artifacts: backboneguard.json, smoketest.json, calibration.json, resultssummarystudents.csv

4. Rebuild real-time demo
   - Manual labeling (keyboard mapping, clickable bar → per-frame CSV + events CSV)
   - Video manual labeling (video input + manual events logging)
   - Real-time parameter adjustment (EMA α, hysteresis δ, vote window/min-count, emo-ratio overlay)
   - Detection methods: YuNet (preferred), DNN, Haar
   - Required artifacts: demoresultssummary.csv, thresholds.json (optional), logit_bias.json (optional)

5. Begin NL + NegL training (student model)
   - NL safeguards: AMP, memory downsizing, gradient accumulation, KD ramp, gradient clipping
   - NegL design: teacher confusion matrix guidance, class-aware ratio, uncertainty gate, minority protection
   - Required artifacts: neglconfig.json, neglrules.md, NL smoke logs

Additional artifacts needed for reproducibility  
- Alignment artifacts: alignmentreport.json, classorder.json, hash_manifest.json for each teacher softlabel export  
- Standardized calibration.json schema across teacher and student models  
- ONNX + latency benchmarks: onnxexportreport.json, onnxparity.json, latencybenchmarks.csv  
- Domain adaptation validation set: small webcam validation set with before/after logs, fairness checks (lighting/pose)
- Training logs and summaries: comprehensive logs for all training runs, including hyperparameters and performance metrics.