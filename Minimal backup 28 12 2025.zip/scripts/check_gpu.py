from tools.diagnostics.check_gpu import *  # noqa: F401,F403
