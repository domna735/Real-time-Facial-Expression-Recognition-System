from tools.diagnostics.check_gpu_dml import *  # noqa: F401,F403
